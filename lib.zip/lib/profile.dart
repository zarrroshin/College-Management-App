import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  TextEditingController usernameController = TextEditingController();
  TextEditingController studentIdController = TextEditingController();
  TextEditingController departmentController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  final String serverAddress = "172.21.192.1"; // Default to localhost

  Future<void> fetchProfileData() async {
    final String url = 'http://172.21.192.1:8080';

    final response = await http.post(
      Uri.parse(url),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(<String, String>{
        'command': 'GET:profile',
        'username': 'your_username', // Replace with the actual username
      }),
    );

    if (response.statusCode == 200) {
      final Map<String, dynamic> data = jsonDecode(response.body);
      if (data['command'] == 'GET:profile') {
        setState(() {
          usernameController.text = data['username'];
          studentIdController.text = data['studentId'];
          departmentController.text = data['department'];
          phoneController.text = data['phone'];
        });
      } else {
        showErrorDialog(context, 'Error', 'Failed to fetch profile data.');
      }
    } else {
      showErrorDialog(context, 'Error', 'Failed to fetch profile data.');
    }
  }


  Future<void> saveProfileData() async {
    const String url = 'http://172.21.192.1:8080'; // Replace with your server's IP and port

    final response = await http.post(
      Uri.parse(url),
      headers: <String, String>{
        'Content-Type': 'application/json; charset=UTF-8',
      },
      body: jsonEncode(<String, String>{
        'command': 'POST:updateProfile',
        'username': usernameController.text,
        'studentId': studentIdController.text,
        'department': departmentController.text,
        'phone': phoneController.text,
      }),
    );

    if (response.statusCode == 200) {
      final Map<String, dynamic> data = jsonDecode(response.body);
      if (data['status'] == 'success') {
        showErrorDialog(context, 'Success', 'Profile updated successfully.');
      } else {
        showErrorDialog(context, 'Error', data['message'] ?? 'Failed to update profile.');
      }
    } else {
      showErrorDialog(context, 'Error', 'Failed to update profile.');
    }
  }

  void showErrorDialog(BuildContext context, String title, String content) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(title),
          content: Text(content),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }

  @override
  void initState() {
    super.initState();
    fetchProfileData();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Align(
          alignment: Alignment.bottomRight,
          child: Text(
            'صفحه کاربری',
            style: TextStyle(
              color: Colors.white,
              fontSize: 23,
              fontWeight: FontWeight.bold,
              fontFamily: 'Roboto',
            ),
          ),
        ),
        backgroundColor: Colors.indigo,
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () {
              showDialog(
                context: context,
                builder: (BuildContext context) {
                  return AlertDialog(
                    title: Text('خروج از حساب کاربری'),
                    content: Text('آیا از خروج از حساب کاربری خود مطمئن هستید؟'),
                    actions: [
                      TextButton(
                        onPressed: () {
                          Navigator.pushReplacementNamed(context, '/login');
                        },
                        child: Text('خروج'),
                      ),
                      TextButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text('انصراف'),
                      ),
                    ],
                  );
                },
              );
            },
          ),
        ],
      ),
      body: FutureBuilder(
        future: fetchProfileData(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error loading profile data'));
          } else {
            return buildProfileContent();
          }
        },
      ),
    );
  }

  Widget buildProfileContent() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                margin: EdgeInsets.only(bottom: 16),
                height: 190,
                width: 200,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  image: DecorationImage(
                    image: AssetImage('assets/profile_picture.jpg'),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
            SizedBox(height: 40),
            buildEditableField(
              context,
              'نام کاربری',
              'نام کاربری خود را وارد کنید',
              usernameController,
              false,
            ),
            SizedBox(height: 10),
            buildEditableField(
              context,
              'شماره دانشجویی',
              'شماره دانشجویی خود را وارد کنید',
              studentIdController,
              false,
            ),
            SizedBox(height: 10),
            buildEditableField(
              context,
              'دانشکده',
              'دانشکده خود را وارد کنید',
              departmentController,
            ),
            SizedBox(height: 10),
            buildEditableField(
              context,
              'شماره تماس',
              'شماره تماس خود را وارد کنید',
              phoneController,
            ),
            SizedBox(height: 80),
            ElevatedButton(
              onPressed: saveProfileData,
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all(Colors.indigo),
              ),
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 32.0, vertical: 16.0),
                child: Text(
                  'ذخیره تغییرات',
                  style: TextStyle(fontSize: 18, color: Colors.white),
                ),
              ),
            ),
            SizedBox(height: 20),
            TextButton(
              onPressed: () {
                showDialog(
                  context: context,
                  builder: (BuildContext context) {
                    return AlertDialog(
                      title: Text('حذف حساب کاربری'),
                      content: Text('آیا از حذف حساب کاربری خود مطمئن هستید؟'),
                      actions: [
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: Text('حذف'),
                        ),
                        TextButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: Text('انصراف'),
                        ),
                      ],
                    );
                  },
                );
              },
              child: Text(
                'حذف حساب کاربری',
                style: TextStyle(color: Colors.red),
              ),
            ),
            SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget buildEditableField(BuildContext context, String label, String hint, TextEditingController controller, [bool editable = true]) {
    return TextFormField(
      controller: controller,
      textAlign: TextAlign.right,
      decoration: InputDecoration(
        labelText: label,
        hintText: hint,
        filled: true,
        fillColor: Colors.grey[200],
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10.0),
          borderSide: BorderSide.none,
        ),
        suffixIcon: editable
            ? IconButton(
          icon: Icon(Icons.edit),
          onPressed: () {},
        )
            : null,
      ),
      enabled: editable,
    );
  }
}
