import 'dart:io';

Future<String?> getIpAddress() async {
  for (var interface in await NetworkInterface.list()) {
    for (var addr in interface.addresses) {
      if (addr.address == '172.21.192.1') {
        return addr.address;
      }
    }
  }
  return null;
}

Future<void> main() async {
  String? ipAddress = await getIpAddress();
  if (ipAddress != null) {
    print(ipAddress);
  } else {
    print('IP address not found');
  }
}
